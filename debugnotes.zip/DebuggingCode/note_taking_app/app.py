from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# This list stays alive as long as the server is running
notes = []


@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        note = request.form.get("note")

        # .strip() makes sure they didn't just type spaces
        if note and note.strip():
            notes.append(note.strip())

        # This "Post-Redirect-Get" pattern stops duplicate notes on refresh
        return redirect(url_for("index"))

    return render_template("home.html", notes=notes)


if __name__ == "__main__":
    app.run(debug=True)
