# URL Shortener

A simple web application built with Flask that allows users to shorten URLs and view their history.

## Features

- Shorten long URLs into compact short codes
- Redirect to original URLs using short codes
- View history of all shortened URLs
- Clean and responsive web interface

## Installation

1. Clone the repository or download the files.
2. Install the required dependencies:

```bash
pip install -r requirements.txt
```

## Usage

1. Run the application:

```bash
python app.py
```

2. Open your web browser and go to `http://localhost:5000`
3. Enter a URL in the input field and click "Shorten URL"
4. Copy the generated short URL
5. Use the short URL to redirect to the original URL
6. View all shortened URLs in the history page

## Technologies Used

- Flask - Web framework
- Flask-SQLAlchemy - Database ORM
- SQLite - Database
- HTML/CSS/JavaScript - Frontend

## Project Structure

```
url_shortener/
├── app.py              # Main Flask application
├── models.py           # Database models
├── requirements.txt    # Python dependencies
├── static/
│   └── style.css       # CSS styles
├── templates/
│   ├── index.html      # Home page template
│   └── history.html    # History page template
└── database.db         # SQLite database (created automatically)
```